function firstButtonChange()
{
    const ele=document.getElementById("image");
    ele.src="https://i.pinimg.com/originals/8f/fc/8f/8ffc8fd43ab059280ab3a4937c567548.jpg"

}

function secondButtonChange()
{
    const ele=document.getElementById("image");
    ele.src="https://i.pinimg.com/originals/76/61/46/7661468eb5a330ead9b0e1cccc57ed80.png"

}

function thirdButtonChange()
{
    const ele=document.getElementById("image");
    ele. src="https://i.ndtvimg.com/i/2017-05/prabhas_640x480_81493811760.jpg"

}



