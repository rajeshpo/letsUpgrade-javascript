const friends=[
    {
        name:"Rajesh",
        age:23,
        country:"india",
        hobbies:["playing","webdevelopment","cricket","dancing"]
    },
    {
        name:"venkatesh",
        age:23,
        country:"india",
        hobbies:["watching","gymmer","waste fellow"]
    },

    {
        name:"chandu",
        age:23,
        country:"india",
        hobbies:["watching","reading","big waste fellow"]
    }
]

function display(){
    friends.forEach( function(friend){
        console.log(friend);
    });
}

display();