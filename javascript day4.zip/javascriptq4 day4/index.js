const friends=[
    {
        name:"Rajesh",
        age:45,
        country:"india",
        hobbies:["playing","webdevelopment","cricket","dancing"]
    },
    {
        name:"venkatesh",
        age:21,
        country:"Italy",
        hobbies:["watching","gymmer","waste fellow"]
    },

    {
        name:"chandu",
        age:31,
        country:"Russia",
        hobbies:["watching","reading","big waste fellow"]
    }
]

function display(){
    friends.forEach( function(friend){
        if(friend.age<30)
        console.log(friend);
    });
}

display();

function displayCountry(){
    friends.forEach( function(friend){
        if(friend.country=="india")
        console.log(friend);
    });
}
displayCountry();








