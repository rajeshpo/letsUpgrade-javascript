function copy()
{
    const ele=document.getElementsByClassName("form-group");
    const copy=ele[0].value;
    ele[1].value=copy;

}